package com.example.pertemuan8

class MyFriend (
    val name: String,
    val phone: String,
    val email: String,
    val imageID : Int
)
